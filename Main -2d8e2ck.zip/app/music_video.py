"""Static-cover H.264/AAC videos: warm up the encoder, then copy one GOP.

The image never changes. Re-encoding 9,000 identical 2K frames is unnecessary;
loop a closed GOP with monotonic timestamps and mux the original full music.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import subprocess
import shutil
import tempfile
import time


@dataclass(frozen=True)
class MusicVideoResult:
    path: Path
    duration: float
    elapsed_seconds: float
    template_seconds: float
    mux_seconds: float
    audio_copy: bool
    video_bitrate_kbps: float


def run_media(command: list[str], timeout: float = 180) -> None:
    result = subprocess.run(command, capture_output=True, timeout=timeout, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", errors="replace")[-2000:])


def media_executable(name: str, value: str = "") -> str:
    return value or os.environ.get(name.upper() + "_PATH", "") or shutil.which(name) or name


def probe_audio(source: Path, ffprobe: str = "") -> dict:
    ffprobe = media_executable("ffprobe", ffprobe)
    result = subprocess.run([ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(source)],
                            capture_output=True, timeout=30, check=False)
    if result.returncode:
        raise ValueError("音乐文件不能读取：" + result.stderr.decode("utf-8", errors="replace")[-500:])
    payload = json.loads(result.stdout)
    audio = next((s for s in payload.get("streams", []) if s.get("codec_type") == "audio"), None)
    if not audio or any(s.get("codec_type") == "video" for s in payload.get("streams", [])):
        # Album art is a legal attached picture, not a music video.
        if not audio or any(s.get("codec_type") == "video" and not s.get("disposition", {}).get("attached_pic") for s in payload.get("streams", [])):
            raise ValueError("下载文件不是纯音频作品")
    duration = float(payload.get("format", {}).get("duration") or audio.get("duration") or 0)
    if not math.isfinite(duration) or not 0 < duration <= 3600:
        raise ValueError("音乐时长无效或超过一小时")
    return {"duration": duration, "codec": audio.get("codec_name"), "channels": int(audio.get("channels") or 0), "streams": payload.get("streams", [])}


def make_music_video(image: Path, audio: Path, destination: Path, *, ffmpeg: str = "",
                     ffprobe: str = "", width: int = 2560, height: int = 1440,
                     fps: int = 30, bitrate_kbps: int = 4000, timeout: float = 180) -> MusicVideoResult:
    ffmpeg, ffprobe = media_executable("ffmpeg", ffmpeg), media_executable("ffprobe", ffprobe)
    if not image.is_file() or not audio.is_file():
        raise ValueError("封面或原始音乐不存在")
    if (width, height) != (2560, 1440) or fps != 30 or not 1000 <= bitrate_kbps <= 10000:
        raise ValueError("音乐视频固定为 2560×1440、30fps；码率须在 1000–10000 kbps")
    if destination.exists():
        raise ValueError("拒绝覆盖已有音乐视频")
    started = time.perf_counter()
    info = probe_audio(audio, ffprobe)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="music-cover-", dir=destination.parent) as temporary:
        clip = Path(temporary) / "cover.mp4"
        warmup = Path(temporary) / "warmup.mp4"
        output = Path(temporary) / "result.mp4"
        # Closed GOP: no references outside this 1-second clip. HRD filler
        # provides a true constant video bitrate even on a static image.
        run_media([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-loop", "1", "-framerate", str(fps),
                   "-i", str(image), "-t", "3", "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p",
                   "-an", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "stillimage", "-threads", "4",
                   # A quarter-second VBV keeps each repeated GOP close to CBR.
                   # A two-second buffer lets detailed IDRs borrow across GOPs;
                   # repeating one such GOP repeats the overshoot indefinitely.
                   "-b:v", f"{bitrate_kbps}k", "-minrate", f"{bitrate_kbps}k", "-maxrate", f"{bitrate_kbps}k", "-bufsize", f"{bitrate_kbps // 4}k",
                   "-g", str(fps), "-keyint_min", str(fps), "-sc_threshold", "0", "-bf", "0",
                   "-x264-params", "nal-hrd=cbr:force-cfr=1:open-gop=0", str(warmup)], timeout)
        # Do not repeat the VBV startup deficit 300 times. Keep a warmed,
        # independently decodable one-second GOP, so actual CBR matches target.
        run_media([ffmpeg,"-v","error","-nostdin","-ss","2","-i",str(warmup),"-t","1","-c:v","copy","-an",str(clip)], timeout)
        template_done = time.perf_counter()
        copy_audio = info["codec"] == "aac" and 0 < info["channels"] <= 2
        args = [ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-stream_loop", "-1", "-i", str(clip),
                "-i", str(audio), "-map", "0:v:0", "-map", "1:a:0", "-t", str(info["duration"]), "-c:v", "copy"]
        args += ["-c:a", "copy"] if copy_audio else ["-c:a", "aac", "-aac_coder", "fast", "-b:a", "192k", "-ac", "2", "-threads", "2"]
        args += ["-map_metadata", "-1", "-movflags", "+faststart", str(output)]
        run_media(args, timeout)
        mux_done = time.perf_counter()
        check = subprocess.run([ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(output)], capture_output=True, timeout=30, check=True)
        data = json.loads(check.stdout)
        video = next((s for s in data["streams"] if s["codec_type"] == "video"), {})
        sound = next((s for s in data["streams"] if s["codec_type"] == "audio"), {})
        if video.get("codec_name") != "h264" or sound.get("codec_name") != "aac" or video.get("width") != width or video.get("height") != height:
            raise RuntimeError("合成结果不是要求的 2K H.264/AAC 视频")
        if abs(float(data["format"]["duration"]) - info["duration"]) > 0.15:
            raise RuntimeError("视频与完整音乐时长不一致")
        measured_bitrate = float(video.get("bit_rate") or 0)/1000
        if abs(measured_bitrate-bitrate_kbps) > bitrate_kbps*.05:
            raise RuntimeError(f"音乐视频实际码率未达到固定码率配置：{measured_bitrate:.1f} kbps，目标 {bitrate_kbps} kbps")
        # Same filesystem atomic publish; no partial file can be delivered.
        output.replace(destination)
    return MusicVideoResult(destination, info["duration"], time.perf_counter() - started,
                            template_done - started, mux_done - template_done, copy_audio, float(video.get("bit_rate") or 0)/1000)


def validate_music_video(video: Path, audio: Path, ffprobe: str = "") -> None:
    ffprobe = media_executable("ffprobe", ffprobe)
    info = probe_audio(audio, ffprobe)
    output = subprocess.run([ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(video)],
                            capture_output=True, timeout=30, check=True)
    data = json.loads(output.stdout)
    picture = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), {})
    sound = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), {})
    if picture.get("codec_name") != "h264" or sound.get("codec_name") != "aac" or (picture.get("width"), picture.get("height")) != (2560,1440):
        raise ValueError("音乐视频编码或分辨率不符合要求")
    if picture.get("avg_frame_rate") != "30/1" or abs(float(picture.get("bit_rate") or 0)-4_000_000) > 200_000:
        raise ValueError("音乐视频帧率或固定码率不符合要求")
    if abs(float(data.get("format", {}).get("duration") or 0)-info["duration"]) > .15:
        raise ValueError("音乐视频时长不匹配原音频")
