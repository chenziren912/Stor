"""Durable, conversation-scoped Music → QQ records → cover → still video.

Original downloads are never replaced by the 50-second voice derivatives.
Ambiguous remote side effects are stopped, not replayed on service restart.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import shutil
import time
from pathlib import Path
from urllib.parse import urlparse

from .flow_video import FlowVideoClient, FlowVideoError
from .llm import ChatCompletionsClient, redact_error_detail
from .music_video import make_music_video, probe_audio, validate_music_video

logger = logging.getLogger(__name__)
MUSIC_TOOLS = {"Builtin_music_generation_create", "Builtin_music_generation_list", "Builtin_music_generation_result"}
IN_FLIGHT = {"voice_sending", "image_generating", "video_sending"}
TERMINAL = {"sent", "failed", "uncertain"}


class FlowMusicClient(FlowVideoClient):
    async def create_music(self, *, prompt, workspace_dir, request_id):
        return await self._request_json("POST", "/v1/music", json_body={"prompt": prompt,
            "workspace_dir": workspace_dir, "request_id": request_id}, request_timeout=self.create_timeout)

    async def get_music(self, job_id):
        if not job_id.startswith("music_") or not all(c in "0123456789abcdef" for c in job_id[6:]):
            raise ValueError("无效音乐任务 ID")
        return await self._request_json("GET", "/v1/music/" + job_id)

    async def resume_music_review(self, job_id):
        await self.get_music(job_id)  # Validate the same existing identifier.
        return await self._request_json("POST", "/v1/music/" + job_id + "/resume-review", json_body={})


class MusicJobs:
    def __init__(self, db):
        self.db = db
        with db.transaction() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS flow_music_jobs (id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, stage TEXT NOT NULL, payload TEXT NOT NULL)")
            conn.execute("CREATE INDEX IF NOT EXISTS music_conversation ON flow_music_jobs(conversation_id)")

    def save(self, job):
        with self.db.transaction() as conn:
            conn.execute("INSERT INTO flow_music_jobs VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET stage=excluded.stage,payload=excluded.payload WHERE flow_music_jobs.conversation_id=excluded.conversation_id",
                         (job["job_id"], job["conversation_id"], job["stage"], json.dumps(job, ensure_ascii=False)))

    def get(self, conversation_id, job_id):
        with self.db.transaction() as conn:
            row = conn.execute("SELECT payload FROM flow_music_jobs WHERE conversation_id=? AND id=?", (conversation_id, job_id)).fetchone()
        return json.loads(row[0]) if row else None

    def list(self, conversation_id=None):
        with self.db.transaction() as conn:
            rows = conn.execute("SELECT payload FROM flow_music_jobs" + (" WHERE conversation_id=?" if conversation_id else ""),
                                (conversation_id,) if conversation_id else ()).fetchall()
        return sorted((json.loads(row[0]) for row in rows), key=lambda j: j["created_at"], reverse=True)

    def recover(self):
        for j in self.list():
            if j["stage"] in IN_FLIGHT:
                j.update(stage="uncertain", error="服务在远程发送/图片生成期间重启，结果未确认，不自动重复；原音频与已有文件保留")
                self.save(j)
            elif j["stage"] == "video_rendering":
                # Local rendering has no remote side effect; inspect an already
                # completed output before considering another local encode.
                j["stage"] = "image_ready"; self.save(j)


async def resume_music_delivery(db, client, conversation_id, job_id):
    """Explicitly recover only pre-delivery work for the same confirmed song.

    Never creates music and never replays audio/image/video side effects.
    A CAS protects a concurrent monitor update from being overwritten.
    """
    store = MusicJobs(db)
    with db.transaction() as conn:
        row = conn.execute("SELECT payload FROM flow_music_jobs WHERE conversation_id=? AND id=?", (conversation_id, job_id)).fetchone()
    if not row:
        raise ValueError("当前会话不存在该音乐任务")
    original = row[0]; job = json.loads(original)
    if any(job.get(k) for k in ("audio_path", "voice_result", "cover_path", "video_path", "video_result")):
        raise ValueError("已进入媒体交付阶段，禁止自动恢复或重发已有副作用")
    if job["stage"] not in {"submitting", "generating", "failed"} or (
        job["stage"] == "failed" and "music_interrupted" not in str(job.get("error", ""))
    ):
        raise ValueError("只恢复服务重启中断的、尚未交付的原音乐任务")
    upstream = await client.get_music(job_id)
    project = urlparse(str(upstream.get("project_url") or ""))
    previous_project = (job.get("browser") or {}).get("project_url")
    if (upstream.get("id") != job_id or upstream.get("prompt") != job["prompt"] or
        upstream.get("submission_confirmed") is not True or upstream.get("submission_unknown") is True or
        project.scheme != "https" or project.hostname not in {"flowmusic.app", "www.flowmusic.app"} or
        not project.path.startswith("/session/") or len(project.path) <= len("/session/") or
        previous_project and previous_project != upstream["project_url"]):
        raise ValueError("必须核实同一已确认歌曲和原会话；未知提交不得恢复交付")
    if upstream.get("status") == "failed":
        if (upstream.get("error") or {}).get("code") != "music_interrupted":
            raise ValueError("不是服务重启中断，需要先核对原歌曲错误")
        upstream = await client.resume_music_review(job_id)
    if upstream.get("status") not in {"queued", "in_progress", "completed"}:
        raise ValueError("原音乐观察未恢复")
    job.setdefault("resume_history", []).append({"at": time.time(), "previous_stage": job["stage"], "previous_error": job.get("error")})
    job["resume_history"] = job["resume_history"][-10:]
    job.update(stage="generating", browser=FlowMusicMixin._music_browser_public(upstream))
    job.pop("error", None)
    with db.transaction() as conn:
        changed = conn.execute("UPDATE flow_music_jobs SET stage=?,payload=? WHERE id=? AND conversation_id=? AND payload=?",
            (job["stage"], json.dumps(job, ensure_ascii=False), job_id, conversation_id, original)).rowcount
    if changed != 1:
        raise ValueError("交付状态已并发变化，未覆盖；请重新查询原任务")
    result = {"ok": True, "job_id": job_id, "stage": job["stage"], "new_generation": False}
    if job.get("turn_id"):
        db.add_tool_audit(job["turn_id"], conversation_id, "music-resume-" + str(time.time_ns()), "music_resume_delivery", {"job_id": job_id}, result, "success")
    return result


async def resume_music_video(db, conversation_id, job_id, workspace):
    """Repair only a failed local render; never replay voice/image side effects."""
    store = MusicJobs(db)
    job = store.get(conversation_id, job_id)
    if not job or job.get("stage") != "failed" or not (
        job.get("failed_stage") == "video_rendering" or
        str(job.get("error", "")).startswith("音乐视频实际码率未达到固定码率配置")
    ):
        raise ValueError("只能恢复明确失败的本地视频合成")
    if (not job.get("audio_path") or not job.get("cover_path") or
        (job.get("voice_result") or {}).get("ok") is not True or
        job.get("video_path") or job.get("video_result")):
        raise ValueError("必须有原音频、封面和已确认语音；已有视频交付不得重放")
    base = Path(workspace).resolve()
    song_dir = (base / "music" / job_id).resolve()
    song_dir.relative_to(base)
    audio, cover = [(base / job[key]).resolve() for key in ("audio_path", "cover_path")]
    for path in (audio, cover):
        path.relative_to(song_dir)
        if not path.is_file():
            raise ValueError("原音频或封面不存在")
    original = json.dumps(job, ensure_ascii=False)
    job.update(stage="video_rendering")
    reserved = json.dumps(job, ensure_ascii=False)
    with db.transaction() as conn:
        changed = conn.execute("UPDATE flow_music_jobs SET stage=?,payload=? WHERE id=? AND conversation_id=? AND payload=?",
            (job["stage"], reserved, job_id, conversation_id, original)).rowcount
    if changed != 1:
        raise ValueError("任务状态已变化，未开始本地恢复")
    video = song_dir / "music-video.mp4"
    reused = video.exists()
    try:
        if reused:
            await asyncio.to_thread(validate_music_video, video, audio)
        else:
            rendered = await asyncio.to_thread(make_music_video, cover, audio, video)
            job["render_seconds"] = rendered.elapsed_seconds
        job.update(stage="video_ready", video_path=video.relative_to(base).as_posix())
        job.pop("error", None)
        job.pop("failed_stage", None)
    except Exception as exc:
        job.update(stage="failed", failed_stage="video_rendering", error=redact_error_detail(exc, limit=1400))
        raise
    finally:
        with db.transaction() as conn:
            changed = conn.execute("UPDATE flow_music_jobs SET stage=?,payload=? WHERE id=? AND conversation_id=? AND payload=?",
                (job["stage"], json.dumps(job, ensure_ascii=False), job_id, conversation_id, reserved)).rowcount
        if changed != 1:
            raise ValueError("恢复期间状态已变化，未覆盖并发更新")
    result = {"ok": True, "job_id": job_id, "stage": "video_ready", "new_generation": False,
              "reused_video": reused, "replayed_voice": False, "regenerated_cover": False}
    if job.get("turn_id"):
        db.add_tool_audit(job["turn_id"], conversation_id, "music-video-resume-" + str(time.time_ns()),
            "music_resume_video", {"job_id": job_id}, result, "success")
    return result


class FlowMusicMixin:
    def _init_flow_music(self):
        self._music_jobs = MusicJobs(self.db)
        self._music_jobs.recover()
        self._music_monitor_task = None
        self._music_tasks = {}
        self._music_creating = set()
        self._music_locks = {}

    def _music_client(self):
        original = self._flow_video_client()
        return FlowMusicClient(original.base_url, original.api_key, timeout=original.timeout, create_timeout=original.create_timeout)

    @staticmethod
    def _music_public(job):
        return {k: job[k] for k in ("job_id", "prompt", "stage", "created_at", "browser", "error", "audio_path", "cover_path", "video_path", "voice_result", "video_result", "render_seconds") if k in job}

    async def _music_notice(self, job, text):
        if not self.adapter or not self.adapter.connected:
            return
        try:
            action, params = self._qq_send_action(job["conversation_id"], [{"type": "text", "data": {"text": text}}])
            response = await self.adapter.call(action, params)
            message_id = str((response.get("data") or {}).get("message_id") or "")
            if message_id:
                self.db.add_sent_message(message_id, job["conversation_id"], job["turn_id"], text)
        except Exception as exc:
            job["notice_warning"] = redact_error_detail(exc, limit=500)
            self._music_jobs.save(job)

    async def _execute_music_tool(self, turn_id, conversation_id, name, args, call_id, *, operation_slot=0, operation_namespace=""):
        result = {"ok": False}
        operation_key = None
        try:
            if name.endswith("_list"):
                result = {"ok": True, "jobs": [self._music_public(j) for j in self._music_jobs.list(conversation_id)[:30]]}
            elif name.endswith("_result"):
                job = self._music_jobs.get(conversation_id, str(args.get("job_id") or ""))
                if not job:
                    raise ValueError("当前会话不存在该音乐任务")
                result = {"ok": True, **self._music_public(job)}
            else:
                prompt = str(args.get("prompt") or "").strip()
                if not prompt or len(prompt) > 4000 or set(args) - {"prompt"}:
                    raise ValueError("音乐仅接受 1..4000 字符 prompt，质量配置固定")
                if not self.settings.llm.image_model or not self.secret_store.get_llm_api_key():
                    raise ValueError("请先设置图片生成模型和 API Key；音乐完整流程需要 AI 封面")
                operation_key, events = self._tool_operation_key(turn_id, conversation_id, operation_slot, operation_namespace=operation_namespace)
                previous = self.db.reserve_tool_operation(operation_key, conversation_id, events, name, args)
                if previous:
                    result = json.loads(previous["result_json"]); result["deduplicated"] = True
                else:
                    request_id = hashlib.sha256(operation_key.encode()).hexdigest()
                    job_id = "music_" + request_id[:32]
                    job = {"job_id": job_id, "conversation_id": conversation_id, "turn_id": turn_id,
                        "prompt": prompt, "created_at": time.time(), "stage": "submitting"}
                    self._music_jobs.save(job)  # Persist identity before the POST can create remote work.
                    self._music_creating.add(job_id)
                    workspace = self.conversation_workspace(conversation_id).resolve()
                    await self._music_notice(job, "正在启动音乐生成子任务。")
                    upstream = await self._music_client().create_music(prompt=prompt, request_id=request_id,
                        workspace_dir=str(workspace / "music" / job_id))
                    job["browser"] = self._music_browser_public(upstream)
                    if upstream.get("submission_confirmed") is not True:
                        job.update(stage="uncertain", error="页面未确认真实音乐任务；保留记录，不重新提交")
                        self._music_jobs.save(job)
                        raise FlowVideoError(job["error"])
                    job["stage"] = "generating"; self._music_jobs.save(job)
                    result = {"ok": True, "async": True, "accepted": True, **self._music_public(job),
                        "message": "音乐页面已确认任务；完成后依次发送50秒语音、生成封面和固定画面完整音乐视频，当前轮结束。"}
                    await self._music_notice(job, "音乐生成任务已确认启动，完成后会发送语音和完整音乐视频。")
        except Exception as exc:
            result = {"ok": False, "error": redact_error_detail(exc, limit=1400)}
            # A timeout is not proof of failure. The persisted job is polled by
            # ID, but never POSTed again, closing the orphan/duplicate window.
        finally:
            if "job_id" in locals(): self._music_creating.discard(job_id)
        status = "success" if result.get("ok") else "failed"
        if operation_key and not result.get("deduplicated"):
            self.db.finish_tool_operation(operation_key, status, result)
        self.db.add_tool_audit(turn_id, conversation_id, call_id, name, args, result, status)
        return result

    @staticmethod
    def _music_browser_public(upstream):
        return {k: upstream[k] for k in ("status", "stage", "account", "settings", "submission_confirmed", "submission_unknown", "project_url", "browser_task", "review_task", "last_observation", "error", "audio", "timings") if k in upstream}

    async def _music_monitor_loop(self):
        while not self._stopping:
            try:
                for job in self._music_jobs.list():
                    if job["stage"] in TERMINAL or job["job_id"] in self._music_tasks or job["job_id"] in self._music_creating:
                        continue
                    group = self.db.get_group(job["conversation_id"])
                    if not group or not self._conversation_enabled_for_runtime(group):
                        continue
                    task = self._track_background_task(self._process_music_job(job))
                    self._music_tasks[job["job_id"]] = task
                    task.add_done_callback(lambda _, key=job["job_id"]: self._music_tasks.pop(key, None))
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Music monitor failed")
            await asyncio.sleep(5)

    async def _process_music_job(self, job):
        lock = self._music_locks.setdefault(job["job_id"], asyncio.Lock())
        async with lock:
            job = self._music_jobs.get(job["conversation_id"], job["job_id"])
            if not job or job["stage"] in TERMINAL:
                return
            base = self.conversation_workspace(job["conversation_id"]).resolve()
            def local(value):
                file = (base / value).resolve(); file.relative_to(base)
                return file
            try:
                if job["stage"] in {"submitting", "generating"}:
                    upstream = await self._music_client().get_music(job["job_id"])
                    job["browser"] = self._music_browser_public(upstream)
                    if upstream.get("status") == "failed":
                        if upstream.get("submission_unknown") is True:
                            job.update(stage="uncertain", error="音乐提交结果未知，未自动重试；请核对原会话。" + str(upstream.get("error") or ""))
                            self._music_jobs.save(job)
                            await self._music_notice(job, job["error"])
                            return
                        raise FlowVideoError(str(upstream.get("error") or "音乐浏览器任务失败"), status_code=409, code="music_browser_failed")
                    if upstream.get("status") != "completed":
                        self._music_jobs.save(job); return
                    files = upstream.get("output_paths") or []
                    if len(files) != 1:
                        raise ValueError("音乐任务没有返回唯一原始音频")
                    audio = Path(files[0]).resolve(); audio.relative_to(base / "music" / job["job_id"])
                    await asyncio.to_thread(probe_audio, audio)
                    job.update(audio_path=audio.relative_to(base).as_posix(), stage="audio_ready"); self._music_jobs.save(job)
                if not self.adapter or not self.adapter.connected:
                    return
                if job["stage"] == "audio_ready":
                    segments = await self._split_audio_for_qq_voice(local(job["audio_path"]), preferred_prefix="生成音乐")
                    job["stage"] = "voice_sending"; self._music_jobs.save(job)
                    sent = await self._send_record_segments(job["conversation_id"], segments, display_filename=local(job["audio_path"]).name)
                    job["voice_result"] = sent
                    for message_id in sent.get("message_ids", []):
                        if message_id: self.db.add_sent_message(message_id, job["conversation_id"], job["turn_id"], "[生成音乐语音]")
                    if not sent.get("ok"):
                        job["stage"] = "uncertain" if sent.get("qq_side_effect") == "unknown" else "failed"
                        raise ValueError(sent.get("error") or "音乐语音发送失败")
                    job["stage"] = "voice_sent"; self._music_jobs.save(job)
                if job["stage"] == "voice_sent":
                    await self._music_notice(job, "图片生成中")
                    job["stage"] = "image_generating"; self._music_jobs.save(job)
                    prompt = "为以下原创音乐制作一张高品质横向专辑封面，无文字、无水印，画面将固定不变地配合整首音乐：\n" + job["prompt"]
                    client = ChatCompletionsClient(self.settings.llm, self.secret_store.get_llm_api_key())
                    generated = await client.generate_image(prompt, size="1792x1024", max_attempts=1)
                    stored = await self._store_generated_image(generated, prompt=prompt)
                    cover = local(job["audio_path"]).parent / ("cover" + stored.path.suffix)
                    await asyncio.to_thread(shutil.copy2, stored.path, cover)
                    job.update(cover_path=cover.relative_to(base).as_posix(), stage="image_ready"); self._music_jobs.save(job)
                if job["stage"] == "image_ready":
                    await self._music_notice(job, "视频制作中")
                    job["stage"] = "video_rendering"; self._music_jobs.save(job)
                    video = local(job["audio_path"]).parent / "music-video.mp4"
                    if not video.exists():
                        rendered = await asyncio.to_thread(make_music_video, local(job["cover_path"]), local(job["audio_path"]), video)
                        job["render_seconds"] = rendered.elapsed_seconds
                    else:
                        await asyncio.to_thread(validate_music_video, video, local(job["audio_path"]))
                    job.update(video_path=video.relative_to(base).as_posix(), stage="video_ready"); self._music_jobs.save(job)
                if job["stage"] == "video_ready":
                    job["stage"] = "video_sending"; self._music_jobs.save(job)
                    sent = await self._send_video_to_conversation(job["conversation_id"], local(job["video_path"]), "原创音乐.mp4")
                    job["video_result"] = sent
                    if not sent.get("ok"):
                        job["stage"] = "uncertain" if "uncertain" in str(sent.get("delivery")) else "failed"
                        raise ValueError(sent.get("error") or "音乐视频发送失败")
                    if sent.get("message_id"):
                        self.db.add_sent_message(sent["message_id"], job["conversation_id"], job["turn_id"], "[生成音乐视频]")
                    job["stage"] = "sent"; self._music_jobs.save(job)
            except asyncio.CancelledError:
                raise  # Persisted in-flight phase is recovered as uncertain.
            except FlowVideoError as exc:
                if not exc.status_code and job["stage"] in {"submitting", "generating"}:
                    job["poll_warning"] = redact_error_detail(exc, limit=600); self._music_jobs.save(job); return
                job.update(stage="failed", error=redact_error_detail(exc, limit=1400)); self._music_jobs.save(job)
                await self._music_notice(job, "音乐任务失败：" + job["error"])
            except Exception as exc:
                job["failed_stage"] = job["stage"]
                if job["stage"] == "image_generating": job["stage"] = "uncertain"
                elif job["stage"] != "uncertain": job["stage"] = "failed"
                job["error"] = redact_error_detail(exc, limit=1400); self._music_jobs.save(job)
                await self._music_notice(job, "音乐后续处理未完成（原始文件保留）：" + job["error"])
