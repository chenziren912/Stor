"""Local, credential-free 5-minute/2K CBR benchmark. No QQ or browser calls."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.music_video import make_music_video, run_media

parser = argparse.ArgumentParser()
parser.add_argument("--seconds", type=int, default=300)
parser.add_argument("--repeats", type=int, default=3)
parser.add_argument("--audio-format", choices=["aac","mp3"], default="aac")
parser.add_argument("--cover", type=Path, help="使用现有真实封面，不复制或改动它")
args = parser.parse_args()
with tempfile.TemporaryDirectory(prefix="qqbot-music-benchmark-") as directory:
    root = Path(directory)
    image, audio = args.cover or root / "cover.png", root / ("music.m4a" if args.audio_format=="aac" else "music.mp3")
    # Detailed synthetic still rather than a trivially compressible flat color.
    if not args.cover:
        run_media(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=2560x1440:rate=1", "-frames:v", "1", str(image)])
    run_media(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000", "-t", str(args.seconds), "-c:a", "aac" if args.audio_format=="aac" else "libmp3lame", "-b:a", "192k", str(audio)])
    for i in range(args.repeats):
        result = make_music_video(image, audio, root / f"music-{i}.mp4")
        # Check decodability at beginning, a GOP boundary, middle and end;
        # this verification time is separate from the synthesis benchmark.
        for second in [0,1,max(0,args.seconds//2),max(0,args.seconds-1)]:
            run_media(["ffmpeg","-v","error","-xerror","-threads","2","-ss",str(second),"-i",str(result.path),"-t","0.1","-threads","2","-f","null","-"])
        print(json.dumps({**asdict(result), "audio_format":args.audio_format,"path": "temporary benchmark output", "within_5s": result.elapsed_seconds <= 5,"sample_decode_ok":True}, ensure_ascii=False, default=str), flush=True)
