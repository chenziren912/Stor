"""Local, explicit recovery of one confirmed song; never calls create."""
import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.db import Database
from app.flow_music import FlowMusicClient, resume_music_delivery, resume_music_video


async def main():
    parser = argparse.ArgumentParser(description="恢复同一首重启中断音乐的交付，不重新生成")
    parser.add_argument("conversation_id")
    parser.add_argument("job_id")
    parser.add_argument("--local-video", type=Path, metavar="WORKSPACE", help="只恢复已失败的本地视频合成，使用此会话工作区；不重发语音或重新生成封面")
    parser.add_argument("--data-dir", type=Path, default=Path(os.environ["LOCALAPPDATA"]) / "QQAIGroupAgent" / "data")
    args = parser.parse_args()
    db = Database(args.data_dir / "agent.sqlite3")
    try:
        if args.local_video:
            result = await resume_music_video(db, args.conversation_id, args.job_id, args.local_video)
        else:
            result = await resume_music_delivery(db, FlowMusicClient(), args.conversation_id, args.job_id)
        print(json.dumps(result, ensure_ascii=False))
    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(main())
