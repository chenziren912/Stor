[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 2147483647)]
    [int]$ExpectedProcessId,
    [string]$ConversationId,
    [string]$MusicJobId
)

$ErrorActionPreference = 'Stop'
if ($ConversationId -or $MusicJobId) {
    if (-not $ConversationId -or $MusicJobId -notmatch '^music_[a-f0-9]{32}$') {
        throw '恢复音乐需要同时提供会话ID与有效的原任务ID。'
    }
}
$projectRoot = Split-Path -Parent $PSScriptRoot
$apiPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'flow-ai\api.mjs'))
$target = Get-CimInstance Win32_Process -Filter "ProcessId=$ExpectedProcessId" -ErrorAction Stop

if ($target) {
    $owners = @(Get-NetTCPConnection -State Listen -LocalPort 8787 -ErrorAction SilentlyContinue |
        Select-Object -ExpandProperty OwningProcess -Unique)
    if ($target.Name -ne 'node.exe' -or
        $target.CommandLine -notmatch ('(?:^|\s)(?:"' + [regex]::Escape($apiPath) + '"|' + [regex]::Escape($apiPath) + ')(?=\s|$)') -or
        $owners -notcontains $ExpectedProcessId) {
        throw '进程身份或8787监听不匹配，拒绝停止。请重新核对Flow PID。'
    }
    $targetProcess = [Diagnostics.Process]::GetProcessById($ExpectedProcessId)
    try {
        $null = $targetProcess.Handle # Pin this process identity, not a later reused PID.
        if ($targetProcess.HasExited -or
            $targetProcess.StartTime.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fff') -ne
            $target.CreationDate.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fff')) {
            throw '进程已退出或身份发生变化，拒绝停止。'
        }
        Write-Host "只停止 Flow Node（PID $ExpectedProcessId）；不会停止 QQBot 或其他 Chrome。"
        Stop-Process -InputObject $targetProcess -ErrorAction Stop
    } finally { $targetProcess.Dispose() }
} else {
    Write-Host "原 PID $ExpectedProcessId 已退出；不会停止守护新启动的进程。"
}

$ready = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    try {
        $health = Invoke-RestMethod 'http://127.0.0.1:8787/healthz' -TimeoutSec 1
        if ($health.ok -eq $true -and $health.runtime -eq 'qqbot-ai-browser' -and
            $health.authentication_mode -eq 'persistent_browser_profile' -and
            $health.browser_resources.limit -eq 1) {
            $ready = $true
            break
        }
    } catch { }
    if ($attempt -eq 5) {
        $guardPath = Join-Path $PSScriptRoot 'flow-api-guard.ps1'
        $guardProcesses = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" |
            Where-Object { $_.CommandLine -match [regex]::Escape($guardPath) -and $_.CommandLine -match '(?i)-Guard(?:\s|$)' })
        if ($guardProcesses.Count -eq 0) {
            Start-Process powershell.exe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $guardPath)) -WindowStyle Hidden
        }
    }
    Start-Sleep -Seconds 1
}
if (-not $ready) { throw 'Flow未恢复健康；保留原任务，没有重新生成。' }
Write-Host 'Flow已恢复健康，QQBot未停止。'

if ($ConversationId -or $MusicJobId) {
    $python = Join-Path $projectRoot '.venv\Scripts\python.exe'
    & $python (Join-Path $PSScriptRoot 'resume-music-delivery.py') $ConversationId $MusicJobId
    if ($LASTEXITCODE -ne 0) { throw '原音乐任务未恢复；不会新建或重复生成。' }
}
