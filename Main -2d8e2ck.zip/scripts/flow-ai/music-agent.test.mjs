import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { EventEmitter } from "node:events";
import { createMusicRuntime } from "./music-runtime.mjs";
import { musicSettingsProof, musicSettingsMismatch, musicMenuPrecondition, musicPhase, musicEvidence, assertMusicPage, isMusicGenerate, assertMusicSongTarget, musicQualityControl, musicCardTrack, openMusicDownloadMenu, canDownloadMusic, activateMusicAudioFormat, MusicWorker } from "./music-agent.mjs";
import { SubmissionGuard } from "./submission-guard.mjs";

test("quality proof requires three actual setting rows", () => {
  const observation = { url: "https://www.flowmusic.app/session", elements: [
    { label: "Instrument Frontier music models Lyria 3.5" }, { label:"Ghostwriter World class lyric writing Pro" }, { label:"Producer Standard or fast thinking Standard" }] };
  assert.equal(musicSettingsProof(observation).instrument,"Lyria 3.5");
  observation.elements[2].label="Producer Fast"; assert.equal(musicSettingsProof(observation),null);
  assert.equal(musicSettingsMismatch(observation),true);
  assert.equal(musicSettingsProof({elements:[], text:"Lyria 3.5 Pro Standard"}),null);
});

function submitHarness({badAt=0,cancelAt="",blockTrial=false}={}) {
  const url="https://www.flowmusic.app/session?t=true",job={id:"test",prompt:"request",outputDir:"unused"};
  const guard=new SubmissionGuard(job);let observed=0,evaluated=0,decisions=0,paidClicked=false;
  const snapshot=()=>({url,text:"Compose",elements:[
    {id:0,token:"generate",label:"Generate",inner_text:"Generate",disabled:false},
    {id:1,token:"sound",label:"Sound description",value:"request",editable:true},
    {label:"Instrument",inner_text:badAt&&observed>=badAt?"Instrument Lyria 3.0":"Instrument Lyria 3.5"},
    {label:"Ghostwriter",inner_text:"Ghostwriter Pro"},{label:"Producer",inner_text:"Producer Standard"}]});
  const page={setViewportSize:async()=>{},goto:async()=>{},url:()=>url,keyboard:{press:async()=>{}},
    evaluate:async()=>{evaluated++;if(evaluated===2&&cancelAt==="baseline")guard.cancel();return {tracks:[],progress:[]};},
    locator:()=>({isVisible:async()=>true,evaluate:async()=>({label:"Generate",disabled:false}),click:async opts=>{
      if(opts?.trial && blockTrial)throw new Error("menu intercepts pointer events");
      if(!opts?.trial)paidClicked=true;
    }})};
  const worker=new MusicWorker({browser:{acquireCapacity:async()=>{},ensurePage:async()=>page,close:async()=>{}},
    createModel:()=>({request:async()=>{decisions++;return {decision:badAt&&decisions===1?{action:"press",key:"Escape"}:{action:"submit",element:0}};},close:()=>{}}),
    emit:()=>{},persist:async value=>{if(value.promptSent&&cancelAt==="journal")guard.cancel();},
    observePage:async()=>{observed++;if(observed>4)throw Object.assign(new Error("test stop"),{code:"test_stop"});return snapshot();}});
  return {job,guard,worker,clicked:()=>paidClicked};
}
for (const badAt of [2,3]) test(`wrong current music settings invalidate cached quality at snapshot ${badAt}`,async()=>{
  const h=submitHarness({badAt});
  try {await assert.rejects(h.worker.run(h.job,{resolve:()=>{}},h.guard));assert.equal(h.clicked(),false);}
  finally {h.guard.dispose();}
});
for (const cancelAt of ["baseline","journal"]) test(`caller cancellation during ${cancelAt} cannot click Generate`,async()=>{
  const h=submitHarness({cancelAt});
  try {await assert.rejects(h.worker.run(h.job,{resolve:()=>{}},h.guard),{code:"submission_cancelled"});
    assert.equal(h.clicked(),false);assert.equal(Boolean(h.job.promptSent),false);}
  finally {h.guard.dispose();}
});
test("actionability trial failure never journals paid intent or clicks Generate",async()=>{
  const h=submitHarness({blockTrial:true});
  try {await assert.rejects(h.worker.run(h.job,{resolve:()=>{}},h.guard));
    assert.equal(h.clicked(),false);assert.equal(Boolean(h.job.promptSent),false);}
  finally {h.guard.dispose();}
});
test("chat, old songs, and host confusion are not proof", async () => {
  const old = "/song/old", fresh = "/song/new";
  assert.equal((await musicEvidence({evaluate:async()=>({tracks:[old],progress:[]})},[old])).confirmed,false);
  assert.deepEqual((await musicEvidence({evaluate:async()=>({tracks:[old,fresh],progress:[]})},[old])).fresh,[fresh]);
  assert.equal((await musicEvidence({evaluate:async()=>({tracks:[],progress:["music_progressbar","50%"]})},[])).confirmed,false);
  assert.equal((await musicEvidence({evaluate:async()=>({tracks:[],progress:["Cancel generation"]})},{tracks:[],progress:["Cancel generation"]})).confirmed,false);
  assert.equal((await musicEvidence({evaluate:async()=>({tracks:["https://attacker.com/song/fake"],progress:[]})},[])).confirmed,false);
  assert.deepEqual((await musicEvidence({evaluate:async()=>({tracks:["https://flowmusic.app/song/new?x=1"],progress:[]})},[])).fresh,[fresh]);
  assert.throws(()=>assertMusicPage("https://flowmusic.app.attacker.com/session"));
  assert.throws(()=>assertMusicPage("https://accounts.google.com/signin"));
  assert.throws(()=>assertMusicPage("https://flowmusic.app/login"));
  assert.equal(isMusicGenerate("Send message"),false); assert.equal(isMusicGenerate("Generate"),true);
});
test("settings proof advances the Agent to compose, not configure again",()=>{
  const observation={elements:[{label:"Chat settings",expanded:"false"}]};
  assert.equal(musicPhase({},observation),"configure");
  assert.equal(musicPhase({settingsProof:{}},observation),"compose");
  observation.elements[0].expanded="true";
  assert.equal(musicPhase({settingsProof:{}},observation),"close_settings");
  assert.equal(musicPhase({promptSent:true},observation),"review");
});
test("Instrumental and composer controls do not invalidate fixed quality proof",()=>{
  for (const label of ["Toggle instrumental mode", "Instrumental", "Toggle compose panel", "Sound description", "Chat settings"])
    assert.equal(musicQualityControl(label),false,label);
  for (const label of ["Instrument Frontier music models Lyria 3.5", "Ghostwriter Pro", "Producer Standard", "Lyria 3.5", "Pro", "Standard"])
    assert.equal(musicQualityControl(label),true,label);
});
test("confirmed song click gate accepts normalized URLs but rejects old songs and other hosts",()=>{
  for (const href of ["/song/new", "/song/new/?x=1", "https://flowmusic.app/song/new?x=1", "https://www.flowmusic.app/song/new/"])
    assert.equal(assertMusicSongTarget(href,"https://www.flowmusic.app/session/current",["new"]),"/song/new");
  for (const href of ["/song/old", "https://attacker.com/song/new", "http://www.flowmusic.app/song/new", "/session/elsewhere"])
    assert.throws(()=>assertMusicSongTarget(href,"https://www.flowmusic.app/session/current",["new"]));
});
test("session downloads require a verified fresh song menu owner, not a matching title",async()=>{
  const url="https://www.flowmusic.app/session/current?t=true";
  const j={projectUrl:url,submissionConfirmed:true,trackIds:["new"]};
  const e={fresh:["/song/new"]};
  assert.equal(canDownloadMusic(j,url,e),false);
  j.downloadMenuTrackId=await musicCardTrack({evaluate:async()=>["https://flowmusic.app/song/new/?x=1"]},url,j.trackIds);
  assert.equal(canDownloadMusic(j,url,e),true);
  assert.equal(canDownloadMusic(j,url,{fresh:[]}),false);
  assert.equal(canDownloadMusic(j,"https://www.flowmusic.app/session/elsewhere",e),false);
  assert.equal(canDownloadMusic(j,"https://attacker.com/session/current?t=true",e),false);
  assert.equal(canDownloadMusic({...j,downloadMenuTrackId:"old"},url,e),false);
  assert.equal(canDownloadMusic(j,"https://www.flowmusic.app/song/new/",{fresh:[]}),true);
  for(const refs of [[],["/song/old"],["/song/new","/song/old"],["https://attacker.com/song/new"]])
    await assert.rejects(musicCardTrack({evaluate:async()=>refs},url,j.trackIds));
});
test("failed or unexpanded menu clicks never retain a download owner",async()=>{
  const job={trackIds:["new"],downloadMenuTrackId:"old"},base="https://www.flowmusic.app/session/current";
  const locator={evaluate:async()=>["/song/new"],click:async()=>{throw new Error("old menu overlay");},getAttribute:async()=>"true"};
  await assert.rejects(openMusicDownloadMenu(locator,job,base));assert.equal(job.downloadMenuTrackId,undefined);
  locator.click=async()=>{};locator.getAttribute=async()=>"false";job.downloadMenuTrackId="old";
  await assert.rejects(openMusicDownloadMenu(locator,job,base));assert.equal(job.downloadMenuTrackId,undefined);
  locator.getAttribute=async()=>"true";await openMusicDownloadMenu(locator,job,base);
  assert.equal(job.downloadMenuTrackId,"new");
});
test("audio format uses normal keyboard activation in hover submenus",async()=>{
  const actions=[],locator={press:async key=>actions.push(key),click:async()=>actions.push("click")};
  await activateMusicAudioFormat(locator,{role:"menuitem",label:"MP3"});assert.deepEqual(actions,["Enter"]);
  await activateMusicAudioFormat(locator,{role:"button",label:"M4A"});assert.deepEqual(actions,["Enter","click"]);
  for(const label of ["Download video","Get stems","Download","Original video"])
    await assert.rejects(activateMusicAudioFormat(locator,{role:"menuitem",label}));
});
test("concurrent resume requests schedule only one original-song observer",async()=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),"qqbot-music-resume-test-"));
  let runtime,acquired=0;
  try {
    const journal=path.join(directory,"flow-music-jobs"),id=`music_${"b".repeat(32)}`;
    await fs.mkdir(journal);await fs.writeFile(path.join(journal,id+".json"),JSON.stringify({id,account:1,promptSent:true,
      status:"failed",projectUrl:"https://www.flowmusic.app/session/original",createdAt:1,outputPaths:[]}));
    runtime=await createMusicRuntime({dataDir:directory,count:2,browserFactory:()=>({acquireCapacity:async()=>{acquired++;throw new Error("test stop");},close:async()=>{}}),
      createModel:()=>{throw new Error("must not invoke model");},safeWorkspace:()=>directory});
    const statuses=[];
    await Promise.all([1,2].map(()=>runtime.route({method:"POST"},{},new URL(`http://127.0.0.1/v1/music/${id}/resume-review`),
      {json:(_,code)=>statuses.push(code)})));
    await runtime.close();assert.deepEqual(statuses.sort(),[200,409]);assert.equal(acquired,1);
  } finally {await runtime?.close();await fs.rm(directory,{recursive:true,force:true});}
});
test("same profile music jobs serialize, not capacity-reenter",async()=>{
  const worker=new MusicWorker({}); let active=0, peak=0;
  worker.runUnlocked=async()=>{active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,5));active--;};
  await Promise.all([worker.run({}),worker.run({}),worker.run({})]); assert.equal(peak,1);
});
test("expanded Chat settings directs Agent to Escape without repeating intercepted clicks",()=>{
  const observation={elements:[{id:7,label:"Chat settings",expanded:"true"}]};
  for (const action of [{action:"click",element:7},{action:"fill",element:8},{action:"submit",element:9}])
    assert.throws(()=>musicMenuPrecondition(observation,action),/Escape/);
  assert.doesNotThrow(()=>musicMenuPrecondition(observation,{action:"press",key:"Escape"}));
  assert.doesNotThrow(()=>musicMenuPrecondition(observation,{action:"click",element:10}));
  observation.elements[0].expanded="false";
  assert.doesNotThrow(()=>musicMenuPrecondition(observation,{action:"fill",element:8}));
});
test("disconnected create caller cancels before journal and browser startup",async()=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),"qqbot-music-cancel-test-"));
  let acquired=0, runtime;
  try {
    runtime=await createMusicRuntime({dataDir:directory,count:2,
      browserFactory:()=>({acquireCapacity:async()=>{acquired++;throw new Error("must not launch");},close:async()=>{}}),
      createModel:()=>{throw new Error("must not invoke model");},safeWorkspace:()=>directory});
    const response=new EventEmitter(); response.destroyed=true;response.writableEnded=false;
    let status;
    await runtime.route({method:"POST"},response,new URL("http://127.0.0.1/v1/music"),
      {body:async()=>({prompt:"test",request_id:"a".repeat(64),workspace_dir:directory}),json:(_,code)=>{status=code;}});
    await runtime.close();
    assert.equal(acquired,0);assert.equal(status,502);
    const job=JSON.parse(await fs.readFile(path.join(directory,"flow-music-jobs",`music_${"a".repeat(32)}.json`),"utf8"));
    assert.equal(job.preSubmissionCancelled,true);assert.equal(job.status,"failed");
  } finally {await runtime?.close();await fs.rm(directory,{recursive:true,force:true});}
});
