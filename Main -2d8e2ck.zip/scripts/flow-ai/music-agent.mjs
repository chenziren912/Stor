/** Music uses the same lazy persistent-profile browser capacity as video.
 * Only rendered DOM and real browser download events are used as evidence. */
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { promisify } from "node:util";
import { execFile } from "node:child_process";
import { observe, REVIEW_INTERVAL_MS } from "./browser-agent.mjs";

const execute = promisify(execFile);
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const failure = (message, code) => Object.assign(new Error(message), { code });
async function saveAudioDownload(item, destination, timeoutMs = 120000) {
  let timer;
  try {
    await Promise.race([item.saveAs(destination), new Promise((_, reject) => {
      timer = setTimeout(() => reject(failure("原始音乐下载超过两分钟；保留原歌曲，不重新生成", "music_download_timeout")), timeoutMs);
    })]);
  } finally { clearTimeout(timer); }
}
export const MUSIC_SETTINGS = Object.freeze({ instrument: "Lyria 3.5", ghostwriter: "Pro", producer: "Standard" });
const SETTING_ROWS = [ [/^Instrument\b[\s\S]*Lyria\s*3\.5\s*$/i, /^Instrument\b/i],
  [/^Ghostwriter\b[\s\S]*Pro\s*$/i, /^Ghostwriter\b/i], [/^Producer\b[\s\S]*Standard\s*$/i, /^Producer\b/i] ];
export function musicSettingsMismatch(observation) {
  const labels = observation.elements.map(x => (x.inner_text || x.label || "").trim());
  return SETTING_ROWS.some(([expected, row]) => labels.some(label => row.test(label) && !expected.test(label)));
}
export function musicSettingsProof(observation) {
  const labels = observation.elements.map(x => (x.inner_text || x.label || "").trim());
  const rows = SETTING_ROWS;
  if (musicSettingsMismatch(observation)) return null;
  return rows.every(([pattern]) => labels.some(label => pattern.test(label.trim())))
    ? { ...MUSIC_SETTINGS, observed_url: observation.url, verified_at: Date.now() } : null;
}
export function isMusicGenerate(label) { return /^(Generate|Generate song|Create song|生成|生成歌曲)$/i.test(label.trim()); }
export function musicQualityControl(label) {
  return /^(?:Instrument\b|Ghostwriter\b|Producer\b|Lyria\b|Standard\s*$|Pro\s*$)/i.test(label.trim());
}
const observeMusic = (page, options = {}) => observe(page, { ...options, actionableOnly: true });
export function musicSongRef(ref, base = "https://www.flowmusic.app") {
  try { const u = new URL(ref, base);
    return u.protocol === "https:" && ["flowmusic.app", "www.flowmusic.app"].includes(u.hostname) && /^\/song\/[^/]+\/?$/.test(u.pathname)
      ? u.pathname.replace(/\/$/, "") : null;
  } catch { return null; }
}
export function assertMusicSongTarget(ref, base, trackIds) {
  const normalized = musicSongRef(ref, base);
  if (!normalized || !trackIds?.includes(normalized.slice("/song/".length)))
    throw new Error("只能进入原会话的新歌曲详情，禁止离开到首页/资料库/旧歌曲");
  return normalized;
}
export async function musicCardTrack(locator, base, trackIds) {
  const refs = await locator.evaluate(node => {
    // Radix download menus are portals, so bind their opener to a concrete
    // song link before clicking. Never infer ownership from title/prompt alone.
    for (let parent = node.parentElement, level = 0; parent && level < 6; parent = parent.parentElement, level++) {
      if (parent.matches('main,nav,[role="navigation"]') || parent === document.body) break;
      const refs = [...parent.querySelectorAll('a[href*="/song/"]')].map(x => x.getAttribute("href"));
      if (refs.length) return refs;
    }
    return [];
  });
  const normalized = [...new Set(refs.map(ref => musicSongRef(ref, base)).filter(Boolean))];
  if (normalized.length !== 1) throw new Error("下载菜单必须属于唯一可核实的新歌曲卡片");
  return assertMusicSongTarget(normalized[0], base, trackIds).slice("/song/".length);
}
export function canDownloadMusic(job, currentUrl, evidence) {
  try { assertMusicPage(currentUrl); } catch { return false; }
  const detail = musicSongRef(currentUrl);
  if (!job.submissionConfirmed) return false;
  if (detail) return Boolean(job.trackIds?.includes(detail.slice("/song/".length)));
  return new URL(currentUrl).pathname === new URL(job.projectUrl).pathname &&
    /^\/session\/.+/.test(new URL(currentUrl).pathname) && Boolean(job.downloadMenuTrackId &&
      job.trackIds?.includes(job.downloadMenuTrackId) && evidence.fresh.includes(`/song/${job.downloadMenuTrackId}`));
}
export async function openMusicDownloadMenu(locator, job, base) {
  delete job.downloadMenuTrackId;
  const track = await musicCardTrack(locator, base, job.trackIds);
  await locator.click({ timeout: 15000 });
  if (await locator.getAttribute("aria-expanded") !== "true")
    throw new Error("歌曲菜单尚未展开，未绑定下载归属");
  job.downloadMenuTrackId = track;
}
const isMusicAudioFormat = label => /^(?:MP3|M4A|WAV|FLAC|OGG|AAC)\b/i.test(label.trim());
export async function activateMusicAudioFormat(locator, target) {
  if (!isMusicAudioFormat(target.inner_text || target.label || ""))
    throw new Error("只能激活明确的原始音频格式，不下载视频或 stems");
  if (target.role === "menuitem") await locator.press("Enter", { timeout: 15000 });
  else await locator.click({ timeout: 15000 });
}
export function musicMenuPrecondition(observation, action) {
  const trigger = observation.elements.find(x => /^(?:Chat settings|聊天设置)$/i.test(x.label?.trim() || "") && x.expanded === "true");
  if (trigger && (action.action === "fill" || action.action === "submit" ||
      action.action === "click" && action.element === trigger.id))
    throw new Error('Chat settings 菜单仍展开，遮罩会拦截点击/输入；下一步使用 action=press,key=Escape 关闭菜单，再重新观察。不要重复点菜单触发器。');
}
export function musicPhase(job, observation) {
  if (job.promptSent) return "review";
  if (!job.settingsProof) return "configure";
  return observation.elements.some(x => /^(?:Chat settings|聊天设置)$/i.test(x.label?.trim() || "") && x.expanded === "true") ? "close_settings" : "compose";
}
export function assertMusicPage(url, text = "") {
  const u = new URL(url);
  if (u.protocol !== "https:" || !["flowmusic.app", "www.flowmusic.app"].includes(u.hostname))
    throw failure("Flow Music 未处于已登录应用，请在专用资料浏览器登录", "music_login_required");
  if (/\/(?:login|signin|auth)(?:\/|$)/i.test(u.pathname) || /Couldn't sign you in|Sign in to continue|not available in your country/i.test(text))
    throw failure("Flow Music 页面要求登录或显示地区限制", "music_login_required");
}
export async function musicEvidence(page, baseline) {
  const state = await page.evaluate(() => {
    // Song panels can be siblings of <main>. Only concrete /song/ links on
    // this fresh session qualify; nav links/audio uploads/generic spinners do not.
    const visible = node => { const b = node.getBoundingClientRect(), s = getComputedStyle(node); return b.width && b.height && s.visibility !== "hidden" && s.display !== "none"; };
    const refs = [...document.querySelectorAll('a[href*="/song/"]')].filter(node => !node.closest('nav,[role="navigation"]'));
    const tracks = refs.filter(visible).map(node => node.getAttribute("href")).filter(Boolean);
    const all_tracks = refs.map(node => node.getAttribute("href")).filter(Boolean);
    const progress = [...document.querySelectorAll('button,[role="button"]')].filter(visible).filter(node => !node.closest('nav,[role="navigation"]')).map(node => {
      const text = (node.innerText || node.getAttribute("aria-label") || "").trim();
      return /^(?:Cancel generation|Stop generation)$/i.test(text) ? text : null;
    }).filter(Boolean);
    return { tracks: [...new Set(tracks)], all_tracks: [...new Set(all_tracks)], progress, url: location.href };
  });
  const songRef = ref => musicSongRef(ref, state.url || "https://www.flowmusic.app");
  const previous = Array.isArray(baseline) ? { tracks: baseline, progress: [] } : baseline || {};
  const oldTracks = new Set((previous.tracks || []).map(songRef).filter(Boolean));
  const tracks = [...new Set((state.tracks || []).map(songRef).filter(Boolean))];
  const allTracks = [...new Set((state.all_tracks || state.tracks || []).map(songRef).filter(Boolean))];
  const fresh = tracks.filter(track => !oldTracks.has(track));
  const progress = (state.progress || []).filter(text => /^(?:Cancel generation|Stop generation)$/i.test(text) && !(previous.progress || []).includes(text));
  return { tracks, all_tracks: allTracks, progress, fresh, confirmed: Boolean(fresh.length || progress.length) };
}
export async function validateAudio(file, ffprobe = process.env.FFPROBE_PATH || "ffprobe") {
  const info = await fs.stat(file);
  if (info.size < 1000 || info.size > 400 * 1024 * 1024) throw failure("下载音频大小无效", "music_invalid_download");
  const { stdout } = await execute(ffprobe, ["-v", "error", "-show_streams", "-show_format", "-of", "json", file], { windowsHide: true, timeout: 30000, maxBuffer: 1000000 });
  const data = JSON.parse(stdout), duration = Number(data.format?.duration);
  if (!data.streams?.some(x => x.codec_type === "audio") || data.streams.some(x => x.codec_type === "video" && !x.disposition?.attached_pic)
      || !Number.isFinite(duration) || duration <= 0 || duration > 3600) throw failure("下载文件不是有效原始音乐音频", "music_invalid_download");
  return { duration, bytes: info.size, codec: data.streams.find(x => x.codec_type === "audio").codec_name };
}

export class MusicWorker {
  constructor({ browser, createModel, emit, persist, timeoutMs = 1200000, confirmationTimeoutMs = 90000, observePage = observeMusic, sleep = pause }) {
    Object.assign(this, { browser, createModel, emit, persist, timeoutMs, confirmationTimeoutMs, observePage, sleep });
    this.queue = Promise.resolve(); this.stopping = false;
  }
  run(job, accepted, guard, resume = false) {
    const operation = this.queue.then(() => this.runUnlocked(job, accepted, guard, resume));
    this.queue = operation.catch(() => {}); return operation;
  }
  async close() { this.stopping = true; this.model?.close(); await this.browser.close(); }
  async runUnlocked(job, accepted, guard, resume = false) {
    let model, acquired = false;
    const runStarted = Date.now();
    job.timings ||= {};
    try {
      guard.assert();
      job.stage = "waiting_browser"; this.emit(job, "waiting_browser");
      await this.browser.acquireCapacity(); acquired = true; guard.assert();
      job.timings.queue_ms = Date.now() - job.createdAt * 1000;
      job.stage = "opening_browser"; this.emit(job, "opening_browser");
      if (this.stopping) throw failure("音乐服务停止", "music_stopping");
      model = this.createModel(); this.model = model;
      if (this.stopping) throw failure("音乐服务停止", "music_stopping");
      model = this.createModel(); this.model = model;
      const browserStarted = Date.now();
      const page = await this.browser.ensurePage({ validate: false });
      job.timings.browser_start_ms = Date.now() - browserStarted;
      guard.assert();
      await page.setViewportSize({ width: 1440, height: 1000 });
      const navigationStarted = Date.now();
      await page.goto(resume ? job.projectUrl : "https://www.flowmusic.app/session?t=true", { waitUntil: "domcontentloaded", timeout: 60000 });
      job.timings.navigation_ms = Date.now() - navigationStarted;
      job.pageId = crypto.randomUUID(); job.submitTaskId ||= `submit_${job.id}`;
      let history = [], lastError = "";
      const started = Date.now();
      while (true) {
        const stepStarted = Date.now();
        if (this.stopping) throw failure("音乐服务停止", "music_stopping");
        guard.assert();
        if (job.promptSent && !job.submissionConfirmed && Date.now() - (job.resumedAt || job.sentAt) > this.confirmationTimeoutMs)
          throw failure(job.promptSent ? "音乐页面观察超时；保留原会话，不重复生成" : "音乐配置在 4 分钟内未完成", "music_observation_timeout");
        const observation = await this.observePage(page);
        guard.assert(); assertMusicPage(observation.url, observation.text);
        const observedUrl = new URL(observation.url), currentPath = observedUrl.pathname;
        if (job.promptSent) {
          const song = /^\/song\/([^/]+)\/?$/.exec(currentPath);
          const originalPath = new URL(job.projectUrl).pathname;
          // A fresh /session receives its ID on first generation. Bind that
          // transition once; later navigation is only to a proved new song.
          const firstSession = originalPath === "/session" && /^\/session\/[^/]+$/.test(currentPath);
          if (firstSession) job.projectUrl = observation.url;
          else if (currentPath !== originalPath && !(song && (job.trackIds || []).includes(song[1])))
            throw failure("音乐标签页离开原会话/本次新歌曲；不把其他歌曲冒充结果", "music_session_changed");
        } else {
          if (currentPath !== "/session") throw failure("音乐必须使用全新会话", "music_fresh_session_required");
          job.projectUrl = observation.url;
        }
        job.lastObservedAt = Math.floor(Date.now() / 1000); job.observationCount = (job.observationCount || 0) + 1;
        this.emit(job, "observation", { ...observation, pageId: job.pageId });
        const proof = musicSettingsProof(observation);
        if (proof) job.settingsProof = proof;
        else if (musicSettingsMismatch(observation)) delete job.settingsProof;
        const evidence = await musicEvidence(page, job.before || []);
        if (job.promptSent && currentPath.startsWith("/session")) {
          job.trackIds ||= [];
          for (const ref of evidence.fresh) {
            const match = /^\/song\/([^/?#]+)$/.exec(ref);
            if (match && !job.trackIds.includes(match[1])) job.trackIds.push(match[1]);
          }
        }
        if (job.promptSent && evidence.confirmed && !job.submissionConfirmed) {
          job.submissionConfirmed = true; job.submissionUnknown = false; job.status = "in_progress";
          job.timings.submission_confirmation_ms = Date.now() - job.sentAt;
          job.stage = "ai_reviewing"; job.reviewTaskId = `review_${job.id}`;
          job.submissionEvidence = evidence.fresh.length ? "new_session_music_track" : "session_music_progress";
          await this.persist(job); accepted.resolve(job);
          this.emit(job, "submission_confirmed", { evidence: job.submissionEvidence });
        }
        job.stage = job.submissionConfirmed ? "ai_reviewing" : job.promptSent ? "confirming_submission" : "ai_submitting";
        const modelStarted = Date.now();
        const reply = await model.request({ kind: "music", phase: musicPhase(job, observation),
          request: { prompt: job.prompt, settings: MUSIC_SETTINGS, settings_verified: Boolean(job.settingsProof),
            flow_request_sent: Boolean(job.promptSent), submission_confirmed: Boolean(job.submissionConfirmed), new_tracks: evidence.fresh },
          history: history.slice(-12), last_error: lastError, ...observation });
        job.timings.model_ms = (job.timings.model_ms || 0) + Date.now() - modelStarted;
        guard.assert();
        const action = reply.decision;
        this.emit(job, "ai_action", { phase: job.stage, action: action.action, reason: action.reason, aiModel: reply.model, latency_ms: reply.latency_ms });
        history.push({ action: action.action, element: action.element, reason: action.reason });
        lastError = "";
        const actionStarted = Date.now();
        try {
          if (action.action === "error") throw failure(action.reason || "音乐页面显示错误", "music_page_error");
          if (page.url() !== observation.url) throw new Error("模型返回时页面已导航，先重新观察");
          musicMenuPrecondition(observation, action);
          if (action.action === "wait") { await this.sleep(Math.max(0, REVIEW_INTERVAL_MS - (Date.now()-stepStarted))); continue; }
          if (action.action === "press") {
            if (action.key !== "Escape") throw new Error("音乐页面只允许 Escape 关闭菜单");
            await page.keyboard.press("Escape"); delete job.downloadMenuTrackId; continue;
          }
          if (action.action === "scroll") { await page.mouse.wheel(0, Math.max(-800, Math.min(800, Number(action.scroll_y) || 500))); continue; }
          const target = observation.elements.find(x => x.id === action.element);
          if (!target || target.disabled) throw new Error("目标不是本次观察的有效可见元素");
          const locator = page.locator(`[data-flow-agent="${target.token}"]`);
          if (!await locator.isVisible()) throw new Error("页面元素已改变，请按新观察重新选择");
          const fresh = await locator.evaluate(node => ({ label: (node.getAttribute("aria-label") || node.getAttribute("alt") || node.innerText || node.getAttribute("placeholder") || "").trim().slice(0,500),
            disabled: Boolean(node.disabled) || node.getAttribute("aria-disabled") === "true" }));
          if (fresh.disabled || fresh.label !== target.label) throw new Error("目标文字或可用状态已改变，先重新观察");
          const label = (target.inner_text || target.label || "").trim();
          if (/Music videos|音乐视频|Publish|发布|Delete|删除|Upgrade|购买|订阅|Veo/i.test(label)) throw failure("音乐子任务禁止视频生成、发布、删除或购买", "music_forbidden_action");
          if (action.action === "fill") {
            if (job.promptSent) throw new Error("已点击音乐生成，不再填写或重复提交");
            if (!target.editable || !/Sound description|声音|音色/i.test(target.label)) throw new Error("仅填写 Compose 的 Sound description；不用 Producer 聊天替代真正生成");
            await locator.fill(job.prompt); continue;
          }
          if (isMusicGenerate(label) && action.action !== "submit") throw new Error("真正生成必须使用 submit");
          if (/Send message|发送消息/i.test(label)) throw new Error("禁止把 Producer 聊天当作音乐生成");
          if (action.action === "submit") {
            if (job.promptSent || resume || !isMusicGenerate(label)) throw new Error("拒绝重复提交或非生成按钮");
            if (!job.settingsProof || job.settingsProof.observed_url !== observation.url || !/\/session(?:\/|\?|$)/.test(observation.url)) throw new Error("先实际核验 Lyria 3.5 / Ghostwriter Pro / Producer Standard");
            if (!observation.elements.some(x => /Sound description/i.test(x.label) && x.value?.trim() === job.prompt.trim())) throw new Error("Compose 实际声音描述与请求不符");
            const current = await this.observePage(page, { screenshot: false });
            musicMenuPrecondition(current, action);
            const currentTarget = current.elements.find(x => x.token === target.token);
            if (current.url !== observation.url || musicSettingsMismatch(current) || !currentTarget || currentTarget.disabled || !isMusicGenerate(currentTarget.label)
                || !current.elements.some(x => /Sound description/i.test(x.label) && x.value?.trim() === job.prompt.trim())) throw new Error("提交前页面或实际输入改变，拒绝付费点击");
            guard.assert();
            // Trial performs no input; catches overlays/actionability before
            // intent becomes uncertain and before any paid side effect.
            try { await locator.click({ trial: true, timeout: 3000 }); }
            catch(error) { throw new Error("提交前可操作性检查失败，尚未点击 Generate；按截图先解决菜单遮罩/布局，再提交。" + String(error.message).slice(-350)); }
            guard.assert();
            const before = await musicEvidence(page, []);
            job.before = { tracks: before.all_tracks, progress: before.progress };
            guard.assert();
            const intent = { promptSent: true, submissionUnknown: true, sentAt: Date.now() };
            // Journal intent before the side effect, but keep the in-memory
            // guard cancellable until that async write and final check finish.
            await this.persist({ ...job, ...intent });
            guard.assert();
            if (this.stopping) throw failure("音乐服务停止，未点击生成", "music_stopping");
            Object.assign(job, intent);
            try { await locator.click({ timeout: 15000 }); }
            catch(error) { throw failure("Generate 点击未获确认，提交结果未知；保留原会话，不重复点击。" + String(error.message).slice(-350), "music_submission_click_unknown"); }
            continue;
          }
          if (action.action === "download") {
            const downloadStarted = Date.now();
            if (!canDownloadMusic(job, page.url(), await musicEvidence(page, job.before))) throw new Error("只下载本次新歌曲详情，或从已绑定本次歌曲的卡片菜单下载；先关闭菜单并重新打开该歌曲的 More options。");
            if ((target.has_popup && target.has_popup !== "false") || !isMusicAudioFormat(label)) throw new Error("先打开下载菜单，再选真正的原始音频格式");
            const download = page.waitForEvent("download", { timeout: 60000 });
            download.catch(() => {});
            await activateMusicAudioFormat(locator, target);
            const item = await download;
            const ext = path.extname(item.suggestedFilename()).toLowerCase();
            if (![".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac"].includes(ext)) throw failure("下载不是原始音频格式", "music_invalid_download");
            await fs.mkdir(job.outputDir, { recursive: true });
            const destination = path.join(job.outputDir, `${job.id}${ext}`);
            await saveAudioDownload(item, destination); job.audio = await validateAudio(destination);
            job.timings.download_and_validation_ms = Date.now() - downloadStarted;
            job.timings.submission_to_download_ms = Date.now() - job.sentAt;
            job.outputPaths = [destination]; job.status = "completed"; job.stage = "completed";
            job.completedAt = Math.floor(Date.now() / 1000); await this.persist(job);
            return;
          }
          if (action.action !== "click") throw new Error("不支持的音乐操作");
          if (job.promptSent && /^More options for\b/i.test(label)) {
            await openMusicDownloadMenu(locator, job, observation.url); continue;
          }
          if (!job.promptSent && job.settingsProof && /^(?:Chat settings|聊天设置)$/i.test(label) && target.expanded === "false")
            throw new Error("质量配置已经核验；不要重新打开设置。下一步在 Compose 填写 Sound description，纯音乐开启 Instrumental，然后 submit Generate。");
          if (job.promptSent && target.href) {
            assertMusicSongTarget(target.href, observation.url, job.trackIds);
          }
          if (job.promptSent && /^(?:Songs|Home|Google Flow Music|Profile|Spaces|Turntable|New session|Music videos|Settings menu|Expand Playlists|Expand Projects)$/i.test(label)) throw new Error("生成后不允许离开原音乐任务");
          if (job.promptSent && /Chat settings|New session|Instrument|Ghostwriter|Producer|Generate|Sound description/i.test(label)) throw new Error("生成后只观察原会话，不改设置或创建新会话");
          if (target.href?.includes("/song/") && (!job.promptSent || !evidence.fresh.includes(musicSongRef(target.href, observation.url)))) throw new Error("不能打开本次生成之外的歌曲");
          if (!job.promptSent && musicQualityControl(label)) delete job.settingsProof;
          await locator.click({ timeout: 15000 });
        } catch (error) {
          if (error.code) throw error;
          lastError = String(error.message).slice(-1000);
          this.emit(job, "action_rejected", { error: lastError });
        } finally {
          if (action.action !== "wait") job.timings.browser_action_ms = (job.timings.browser_action_ms || 0) + Date.now() - actionStarted;
        }
      }
    } finally {
      job.timings.worker_ms = (job.timings.worker_ms || 0) + Date.now() - runStarted;
      await this.persist(job).catch(() => {});
      model?.close();
      this.model = null;
      if (acquired) await this.browser.close();
    }
  }
}
