import fs from "node:fs/promises";
import path from "node:path";
import { MusicWorker, MUSIC_SETTINGS } from "./music-agent.mjs";
import { SubmissionGuard, bindSubmissionCaller } from "./submission-guard.mjs";

export function publicMusic(j) {
  return { id: j.id, object: "music", prompt: j.prompt, model: "lyria-3.5", settings: MUSIC_SETTINGS,
    status: j.status, stage: j.stage, account: j.account, created_at: j.createdAt, completed_at: j.completedAt || null,
    submission_confirmed: Boolean(j.submissionConfirmed), submission_unknown: Boolean(j.submissionUnknown),
    project_url: j.projectUrl || null, output_paths: j.outputPaths || [], audio: j.audio || null, error: j.error || null, timings: j.timings || {},
    browser_task: { id: j.submitTaskId || null, status: j.submissionConfirmed ? "completed" : j.status === "failed" ? "failed" : "running" },
    review_task: { id: j.reviewTaskId || null, page_id: j.pageId || null, interval_seconds: 5,
      status: ["failed", "completed"].includes(j.status) ? j.status : j.submissionConfirmed ? "running" : "pending",
      observation_count: j.observationCount || 0, last_observed_at: j.lastObservedAt || null }, last_observation: j.lastObservation || null };
}
export async function createMusicRuntime({ dataDir, count, browserFactory, createModel, safeWorkspace }) {
  const journal = path.join(dataDir, "flow-music-jobs"), jobs = new Map(), saving = new Map(), running = new Set(), signals = new Map();
  await fs.mkdir(journal, { recursive: true });
  let stopping = false, roundRobin = 0;
  const persist = j => {
    const serialized = JSON.stringify(j);
    const next = (saving.get(j.id) || Promise.resolve()).catch(() => {}).then(async () => {
      const file = path.join(journal, `${j.id}.json`);
      await fs.writeFile(file + ".tmp", serialized); await fs.rename(file + ".tmp", file);
    });
    saving.set(j.id, next); return next;
  };
  const emit = (j, event, details = {}) => {
    if (event === "observation") {
      j.lastObservation = { url: details.url, text: details.text.slice(-3000), observed_at: j.lastObservedAt };
      if (details.screenshot) void fs.writeFile(path.join(journal, `${j.id}.jpg`), Buffer.from(details.screenshot.split(",")[1], "base64")).catch(() => {});
    } else {
      j.trace ||= []; j.trace.push({ event, at: Date.now(), ...details }); j.trace = j.trace.slice(-40);
      console.error(JSON.stringify({ job_id: j.id, account: j.account, event, ...details }));
    }
    void persist(j).catch(() => {});
  };
  // Do not launch or infer Music eligibility for profiles 3, 4, 5.
  const workers = Array.from({ length: Math.min(count, 2) }, (_, accountIndex) =>
    new MusicWorker({ browser: browserFactory(accountIndex), createModel, emit, persist }));
  const start = (j, resume = false, { response, persistFirst = false } = {}) => {
    let resolve, reject;
    const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); promise.catch(() => {});
    const accepted = { promise, resolve, reject }, guard = new SubmissionGuard(j);
    guard.onCancel(reject); const signal = { accepted, guard }; signals.set(j.id, signal);
    // Bind before the first async journal write. A lost caller must not leave
    // queued work authorized to perform a paid click later.
    if (response) signal.detach = bindSubmissionCaller(response, guard);
    const operation = Promise.resolve().then(async () => {
      if (persistFirst) await persist(j);
      guard.assert();
      return workers[j.account - 1].run(j, accepted, guard, resume);
    }).catch(async error => {
      j.status = "failed"; j.stage = "failed"; j.completedAt = Math.floor(Date.now()/1000);
      j.error = { code: error.code || "music_browser_failed", message: String(error.message).slice(0,1400) };
      reject(error); await persist(j);
    }).finally(() => { guard.dispose(); running.delete(operation); signals.delete(j.id); });
    running.add(operation); return signal;
  };
  for (const file of await fs.readdir(journal)) {
    if (!/^music_[a-f0-9]+\.json$/.test(file)) continue;
    try {
      const j = JSON.parse(await fs.readFile(path.join(journal,file), "utf8")); jobs.set(j.id,j);
      if (!["completed", "failed"].includes(j.status)) {
        j.status = "failed"; j.stage = "interrupted";
        j.error = { code: "music_interrupted", message: "服务重启，原音乐会话保留；可恢复观察，不自动重新生成" }; await persist(j);
      }
    } catch { /* A corrupt journal never authorizes regeneration. */ }
  }
  return {
    health: () => ({ enabled_account_count: workers.length, authentication_mode: "persistent_browser_profile", settings: MUSIC_SETTINGS,
      ai_browser_control: true, review_interval_seconds: 5, readiness_scope: "music_not_video", active_tasks: running.size }),
    async route(request, response, url, { json, body }) {
      if (request.method === "GET" && url.pathname === "/v1/music") {
        json(response,200,{ object: "list", data: [...jobs.values()].sort((a,b)=>b.createdAt-a.createdAt).slice(0,100).map(publicMusic) }); return true;
      }
      const match = /^\/v1\/music\/(music_[a-f0-9]+)(\/resume-review)?$/.exec(url.pathname);
      if (match) {
        const j = jobs.get(match[1]);
        if (!j) { json(response,404,{ error: { code: "music_not_found", message: "音乐任务不存在" } }); return true; }
        if (request.method === "POST" && match[2]) {
          if (stopping || signals.has(j.id) || !j.promptSent || !j.projectUrl || !/\/session\/.+/.test(new URL(j.projectUrl).pathname) || j.status === "completed") {
            json(response,409,{ error: { message: "只能恢复原音乐会话观察，不重新生成" } }); return true;
          }
          j.status = "in_progress"; j.resumedAt = Date.now(); delete j.downloadMenuTrackId;
          j.lastRecoveryError = j.error; delete j.error;
          // Register the signal synchronously before the first journal await,
          // so concurrent resume requests cannot schedule this same song twice.
          start(j,true,{persistFirst:true});
        } else if (request.method !== "GET" || match[2]) return false;
        json(response,200,publicMusic(j)); return true;
      }
      if (request.method !== "POST" || url.pathname !== "/v1/music") return false;
      let f, outputDir;
      try {
        f = await body(request); f.prompt = String(f.prompt || "").trim();
        if (!f.prompt || f.prompt.length > 4000 || !/^[a-f0-9]{64}$/.test(f.request_id || "")) throw new Error("音乐需要提示词和服务幂等 request_id");
        if (f.model && f.model !== "lyria-3.5") throw new Error("固定 Lyria 3.5 / Ghostwriter Pro / Producer Standard");
        if (f.account && (!Number.isInteger(Number(f.account)) || Number(f.account)<1 || Number(f.account)>workers.length)) throw new Error("只使用已开通的两个音乐账号");
        outputDir = safeWorkspace(f.workspace_dir);
      } catch(error) { json(response,400,{ error: { code: "invalid_parameters", message: error.message } }); return true; }
      if (stopping) { json(response,503,{ error: { message: "音乐服务正在停止" } }); return true; }
      const id = `music_${f.request_id.slice(0,32)}`;
      let j = jobs.get(id), signal = signals.get(id);
      if (j && (j.prompt !== f.prompt || j.outputDir !== outputDir)) { json(response,409,{ error: { message: "request_id 与原请求不一致" } }); return true; }
      if (!j) {
        j = { id, prompt: f.prompt, outputDir, account: Number(f.account) || (roundRobin++ % workers.length + 1),
          status: "queued", stage: "queued", createdAt: Math.floor(Date.now()/1000), outputPaths: [] };
        jobs.set(id,j); signal = start(j, false, { response, persistFirst: true });
      }
      if (!signal) { json(response,200,publicMusic(j)); return true; }
      const detach = signal.detach || bindSubmissionCaller(response, signal.guard);
      try { await signal.accepted.promise; json(response,200,publicMusic(j)); }
      catch(error) { json(response,502,{ error: { code: error.code || "music_submission_failed", message: error.message }, music: publicMusic(j) }); }
      finally { detach(); }
      return true;
    },
    async close() { stopping = true; for (const w of workers) await w.close().catch(()=>{}); await Promise.allSettled([...running]); await Promise.allSettled([...saving.values()]); },
  };
}
