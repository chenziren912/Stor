import json
from types import SimpleNamespace

from app.music_video import make_music_video


def test_static_gop_uses_tight_vbv_and_keeps_originals(tmp_path, monkeypatch):
    import app.music_video as module
    image, audio = tmp_path / "cover.jpg", tmp_path / "song.m4a"
    image.write_bytes(b"cover"); audio.write_bytes(b"original")
    commands = []
    monkeypatch.setattr(module, "probe_audio", lambda *a: {"duration":63.019,"codec":"aac","channels":2})
    def media(command, timeout):
        commands.append(command)
        from pathlib import Path
        Path(command[-1]).write_bytes(b"encoded")
    monkeypatch.setattr(module, "run_media", media)
    data = {"streams":[{"codec_type":"video","codec_name":"h264","width":2560,"height":1440,"bit_rate":"4000000"},
                       {"codec_type":"audio","codec_name":"aac"}],"format":{"duration":"63.033"}}
    monkeypatch.setattr(module.subprocess, "run", lambda *a, **k: SimpleNamespace(stdout=json.dumps(data)))
    result = make_music_video(image, audio, tmp_path / "video.mp4")
    assert commands[0][commands[0].index("-bufsize")+1] == "1000k"
    assert "nal-hrd=cbr:force-cfr=1:open-gop=0" in commands[0]
    assert result.audio_copy and result.video_bitrate_kbps == 4000
    assert image.read_bytes() == b"cover" and audio.read_bytes() == b"original"
