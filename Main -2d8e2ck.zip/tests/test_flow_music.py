import asyncio
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.db import Database
from app.flow_music import FlowMusicMixin, MusicJobs, resume_music_delivery, resume_music_video
from app.llm import TOOLS
from app.tool_facade import model_tools, normalise_call, prepare_model_request


def test_generate_schema_and_strict_branches():
    f = next(t["function"] for t in model_tools(TOOLS) if t["function"]["name"] == "Builtin_generate")
    assert f["parameters"]["properties"]["type"]["enum"] == ["picture", "video", "music"]
    assert "1024x1024" in f["parameters"]["properties"]["size"]["enum"]
    for kind, expected in [("picture", "Builtin_image_generation"), ("music", "Builtin_music_generation_create"), ("video", "Builtin_video_generation_create")]:
        assert normalise_call("Builtin_generate", {"type":kind,"action":"create","prompt":"test"}, TOOLS) == (expected,{"prompt":"test"})
    for args in [{"type":"music","action":"create","prompt":"test","model":"veo"}, {"type":"picture","action":"list"}, {"type":"music","action":"result"}]:
        with pytest.raises(ValueError): normalise_call("Builtin_generate", args, TOOLS)
    subset = [t for t in TOOLS if t["function"]["name"] == "Builtin_music_generation_result"]
    p = model_tools(subset)[0]["function"]["parameters"]["properties"]
    assert p["type"]["enum"] == ["music"] and p["action"]["enum"] == ["result"]


def test_music_persistence_scope_and_recovery(tmp_path):
    db = Database(tmp_path/"db.sqlite3")
    try:
        store = MusicJobs(db)
        for i, stage in enumerate(["voice_sending","image_generating","video_sending","video_rendering","generating"]):
            store.save({"job_id":str(i),"conversation_id":"a","stage":stage,"created_at":i})
        assert store.get("b","0") is None and store.list("b") == []
        store.recover()
        assert [store.get("a",str(i))["stage"] for i in range(5)] == ["uncertain","uncertain","uncertain","image_ready","generating"]
    finally: db.close()


@pytest.mark.asyncio
async def test_explicit_resume_same_confirmed_song_without_create_or_media_replay(tmp_path):
    db=Database(tmp_path/"db.sqlite3");calls=[]
    try:
        store=MusicJobs(db);project="https://www.flowmusic.app/session/original"
        job={"job_id":"music_a","conversation_id":"a","prompt":"test","stage":"failed","created_at":1,
             "error":"music_interrupted","browser":{"project_url":project}}
        store.save(job)
        upstream={"id":"music_a","prompt":"test","submission_confirmed":True,"submission_unknown":False,
                  "project_url":project,"status":"failed","error":{"code":"music_interrupted"}}
        async def get(job_id):calls.append(("get",job_id));return dict(upstream)
        async def resume(job_id):calls.append(("resume",job_id));return {**upstream,"status":"in_progress"}
        client=SimpleNamespace(get_music=get,resume_music_review=resume)
        result=await resume_music_delivery(db,client,"a","music_a")
        assert result["new_generation"] is False and store.get("a","music_a")["stage"]=="generating"
        assert calls==[("get","music_a"),("resume","music_a")]
        assert store.get("a","music_a")["resume_history"][0]["previous_error"]=="music_interrupted"
        for field in ["audio_path","voice_result","cover_path","video_path","video_result"]:
            store.save({**job,field:"already delivered"});calls.clear()
            with pytest.raises(ValueError,match="交付阶段"):await resume_music_delivery(db,client,"a","music_a")
            assert calls==[]
        store.save(job);upstream["submission_unknown"]=True;calls.clear()
        with pytest.raises(ValueError,match="未知提交"):await resume_music_delivery(db,client,"a","music_a")
        assert calls==[("get","music_a")]
        assert store.get("a","music_a")["stage"]=="failed"
    finally:db.close()


@pytest.mark.asyncio
async def test_resume_never_overwrites_concurrent_delivery_state(tmp_path):
    db=Database(tmp_path/"db.sqlite3")
    try:
        store=MusicJobs(db);project="https://www.flowmusic.app/session/original"
        job={"job_id":"music_a","conversation_id":"a","prompt":"test","stage":"failed","created_at":1,"error":"music_interrupted"}
        store.save(job)
        async def get(job_id):
            store.save({**job,"stage":"voice_sent","audio_path":"original.m4a"})
            return {"id":job_id,"prompt":"test","submission_confirmed":True,"submission_unknown":False,"project_url":project,"status":"completed"}
        with pytest.raises(ValueError,match="并发变化"):
            await resume_music_delivery(db,SimpleNamespace(get_music=get),"a","music_a")
        assert store.get("a","music_a")["stage"]=="voice_sent"
    finally:db.close()


@pytest.mark.asyncio
async def test_pipeline_order_and_partial_voice_stops_image(tmp_path, monkeypatch):
    import app.flow_music as module
    calls=[]
    class Store:
        def save(self,j): self.job=dict(j)
        def get(self,*a): return dict(self.job)
    class Host(FlowMusicMixin):
        adapter=SimpleNamespace(connected=True)
        _music_locks={}
        def conversation_workspace(self,c): return tmp_path
        async def _music_notice(self,j,t): calls.append(t)
        async def _split_audio_for_qq_voice(self,*a,**k): calls.append("split"); return ["a","b"]
        async def _send_record_segments(self,*a,**k): calls.append("voice"); return self.voice_result
        async def _store_generated_image(self,*a,**k): calls.append("image_store"); return SimpleNamespace(path=tmp_path/"generated.png")
        async def _send_video_to_conversation(self,*a): calls.append("video_send"); return {"ok":True,"message_id":"video1"}
    class ImageClient:
        def __init__(self,*a): pass
        async def generate_image(self,*a,**k): calls.append("image_generate"); return {}
    def render(image,audio,destination):
        calls.append("render"); assert image.read_bytes()==b"exact AI cover"; assert audio.read_bytes()==b"original music"
        destination.write_bytes(b"fake-test-video"); return SimpleNamespace(elapsed_seconds=1.2)
    monkeypatch.setattr(module,"ChatCompletionsClient",ImageClient)
    monkeypatch.setattr(module,"make_music_video",render)
    (tmp_path/"generated.png").write_bytes(b"exact AI cover")
    (tmp_path/"song.m4a").write_bytes(b"original music")
    host=Host(); host._music_jobs=Store(); host.voice_result={"ok":False,"qq_side_effect":"unknown","message_ids":["v1"],"error":"disconnect"}
    host.db=SimpleNamespace(add_sent_message=lambda *a:None)
    host.settings=SimpleNamespace(llm=object()); host.secret_store=SimpleNamespace(get_llm_api_key=lambda:"test")
    job={"job_id":"x","conversation_id":"a","turn_id":1,"created_at":1,"stage":"audio_ready","audio_path":"song.m4a","prompt":"happy"}
    host._music_jobs.save(job); await host._process_music_job(job)
    assert host._music_jobs.job["stage"] == "uncertain" and "image_generate" not in calls
    calls.clear(); host.voice_result={"ok":True,"message_ids":["v1","v2"]}
    host._music_jobs.save(job); await host._process_music_job(job)
    assert host._music_jobs.job["stage"] == "sent"
    assert calls == ["split","voice","图片生成中","image_generate","image_store","视频制作中","render","video_send"]
    assert (tmp_path/"song.m4a").read_bytes()==b"original music"
    calls.clear(); await host._process_music_job(job); assert calls==[]


@pytest.mark.asyncio
async def test_real_browser_failure_is_terminal(tmp_path):
    class Host(FlowMusicMixin):
        _music_locks={}
        def conversation_workspace(self,c): return tmp_path
        def _music_client(self):
            async def get_music(job_id): return {"status":"failed","error":{"code":"music_login_required","message":"login required"}}
            return SimpleNamespace(get_music=get_music)
        async def _music_notice(self,job,text): self.notices.append(text)
    db=Database(tmp_path/"db.sqlite3")
    try:
        h=Host(); h._music_jobs=MusicJobs(db); h.notices=[]
        j={"job_id":"music_a","conversation_id":"a","turn_id":1,"created_at":1,"stage":"generating"}
        h._music_jobs.save(j); await h._process_music_job(j)
        assert h._music_jobs.get("a","music_a")["stage"] == "failed"
        assert h.notices and "login required" in h.notices[0]
    finally: db.close()


@pytest.mark.asyncio
async def test_unknown_submission_failure_is_not_safe_to_regenerate(tmp_path):
    class Host(FlowMusicMixin):
        _music_locks={}
        def conversation_workspace(self,c):return tmp_path
        def _music_client(self):
            async def get_music(job_id):return {"status":"failed","submission_unknown":True,"error":{"code":"music_confirmation_unknown"}}
            return SimpleNamespace(get_music=get_music)
        async def _music_notice(self,job,text):self.notices.append(text)
    db=Database(tmp_path/"db.sqlite3")
    try:
        h=Host();h._music_jobs=MusicJobs(db);h.notices=[]
        j={"job_id":"music_a","conversation_id":"a","turn_id":1,"created_at":1,"stage":"generating"}
        h._music_jobs.save(j);await h._process_music_job(j)
        assert h._music_jobs.get("a","music_a")["stage"] == "uncertain"
        assert len(h.notices)==1 and "未知" in h.notices[0]
    finally:db.close()


@pytest.mark.asyncio
async def test_music_parent_returns_without_polling_both_protocols():
    from app.config import LLMSettings
    from app.llm import ChatCompletionsClient
    c=ChatCompletionsClient(LLMSettings(model="test"),"test")
    results=[{"tool_name":"Builtin_music_generation_create","result":{"ok":True,"accepted":True,"job_id":"music_a"}}]
    async def forbidden(*a,**k): raise AssertionError("parent must not poll or call LLM again")
    for method,first in [(c._continue_chat_agent,{"messages":[],"first_message":{}}),
                         (c._continue_responses_agent,{"instructions":"","input_items":[],"first_text":""})]:
        r=await method(**first,tool_results=results,warning="",previous_summary="previous",reasoning_effort="off",contains_images=False,tool_executor=forbidden)
        assert r.tool_results==results and "music_a" in r.summary


@pytest.mark.asyncio
async def test_accepted_music_stops_remaining_batch():
    from app.llm import ToolCall, execute_tool_decision
    executed=[]
    async def executor(name,args,call_id,operation_slot):
        executed.append(name)
        return {"ok":True,"accepted":True,"job_id":"music_a"}
    calls=[ToolCall(call_id="first",name="Builtin_music_generation_create",arguments={"prompt":"one"}),
           ToolCall(call_id="second",name="Builtin_music_generation_create",arguments={"prompt":"two"})]
    results=await execute_tool_decision(calls,executor,start_slot=0,phase="test")
    assert executed == ["Builtin_music_generation_create"]
    assert results[1]["result"]["reason"] == "async_job_accepted"
    assert results[1]["result"]["skipped"] is True


def test_old_unified_video_history_and_choice_are_migrated():
    body=prepare_model_request({"tool_choice":{"type":"function","function":{"name":"Builtin_video_generation"}},
        "messages":[{"role":"assistant","tool_calls":[{"function":{"name":"Builtin_video_generation","arguments":'{"action":"result","job_id":"video_a"}'}}]}]})
    assert body["tool_choice"]["function"]["name"] == "Builtin_generate"
    f=body["messages"][0]["tool_calls"][0]["function"]
    assert f["name"] == "Builtin_generate"
    assert json.loads(f["arguments"]) == {"type":"video","action":"result","job_id":"video_a"}


@pytest.mark.asyncio
async def test_resume_only_local_render_never_replays_media(tmp_path, monkeypatch):
    import app.flow_music as module
    db = Database(tmp_path / "db.sqlite3")
    try:
        store = MusicJobs(db)
        directory = tmp_path / "music" / "music_a"
        directory.mkdir(parents=True)
        (directory / "song.m4a").write_bytes(b"original")
        (directory / "cover.jpg").write_bytes(b"original-cover")
        calls = []
        def render(cover, audio, video):
            assert cover.read_bytes() == b"original-cover" and audio.read_bytes() == b"original"
            video.write_bytes(b"validated-video"); calls.append("local-render")
            return SimpleNamespace(elapsed_seconds=2)
        monkeypatch.setattr(module, "make_music_video", render)
        job = {"job_id":"music_a", "conversation_id":"a", "created_at":1, "stage":"failed",
               "failed_stage":"video_rendering", "audio_path":"music/music_a/song.m4a",
               "cover_path":"music/music_a/cover.jpg", "voice_result":{"ok":True,"message_ids":["v1","v2"]}}
        store.save(job)
        with pytest.raises(ValueError): await resume_music_video(db, "b", "music_a", tmp_path)
        result = await resume_music_video(db, "a", "music_a", tmp_path)
        assert result["new_generation"] is False and result["replayed_voice"] is False and result["regenerated_cover"] is False
        restored = store.get("a", "music_a")
        assert restored["stage"] == "video_ready" and restored["render_seconds"] == 2
        assert restored["voice_result"] == job["voice_result"] and calls == ["local-render"]
        for unsafe in [{"stage":"uncertain"}, {"failed_stage":"video_sending"}, {"video_result":{"ok":False}}, {"voice_result":{"ok":False}}]:
            store.save({**job, **unsafe})
            with pytest.raises(ValueError): await resume_music_video(db, "a", "music_a", tmp_path)
        assert calls == ["local-render"]
    finally: db.close()
